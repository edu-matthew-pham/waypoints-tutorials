Upload each folder into its own class in Teachable Machine (Image Project, Standard; on a class, choose Upload and select all the photos in its folder).

Photos from TrashNet (Gary Thung and Mindy Yang, MIT licence); messy benches, low light and crops made from them.
